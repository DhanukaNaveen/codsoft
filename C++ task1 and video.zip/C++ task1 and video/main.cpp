#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0)));
    char userResponse;

    do {
        int secretNumber = rand() % 100 + 1;
        int userGuess;
        int remainingAttempts = 10;

        cout << "Welcome to the Number Guessing Game!" << endl;
        cout << "I've thought of a number between 1 and 100." << endl;
        cout << "Can you guess it within " << remainingAttempts << " attempts?" << endl;

        while (remainingAttempts > 0) {
            cout << "Attempts remaining: " << remainingAttempts << endl;
            cout << "Enter your guess: ";
            cin >> userGuess;

            if (userGuess < secretNumber) {
                cout << "Too low! Guess higher." << endl;
            } else if (userGuess > secretNumber) {
                cout << "Too high! Guess lower." << endl;
            } else {
                cout << "Well done! You've found the correct number: " << secretNumber << endl;
                break;
            }
            --remainingAttempts;
        }

        if (userGuess != secretNumber) {
            cout << "Out of attempts! The correct number was: " << secretNumber << endl;
        }

        cout << "\nWould you like to play again? (Y/N): ";
        cin >> userResponse;

    } while (userResponse == 'Y' || userResponse == 'y');

    return 0;
}
