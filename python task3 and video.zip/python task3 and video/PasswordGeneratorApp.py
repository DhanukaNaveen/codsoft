import random
import string
import tkinter as tk
from tkinter import messagebox

class AdvancedPasswordGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Password Generator")
        self.root.geometry("400x300")

        # Label for password length input
        tk.Label(self.root, text="Enter desired password length:").pack(pady=10)
        self.length_entry = tk.Entry(self.root)
        self.length_entry.pack(pady=5)

        # Checkboxes for complexity options
        self.include_uppercase = tk.BooleanVar(value=True)
        self.include_special = tk.BooleanVar(value=True)
        self.include_numbers = tk.BooleanVar(value=True)

        tk.Checkbutton(self.root, text="Include Uppercase Letters", variable=self.include_uppercase).pack()
        tk.Checkbutton(self.root, text="Include Special Characters", variable=self.include_special).pack()
        tk.Checkbutton(self.root, text="Include Numbers", variable=self.include_numbers).pack()

        # Button to generate password
        generate_btn = tk.Button(self.root, text="Generate Password", command=self.generate_password)
        generate_btn.pack(pady=10)

        # Label to display the generated password
        self.result_label = tk.Label(self.root, text="", font=("Helvetica", 12))
        self.result_label.pack(pady=10)

    def generate_password(self):
        try:
            length = int(self.length_entry.get())
            if length < 1:
                raise ValueError("Length must be greater than 0.")

            # Create a pool of characters based on user choices
            characters = string.ascii_lowercase  # Always include lowercase letters

            if self.include_uppercase.get():
                characters += string.ascii_uppercase
            if self.include_numbers.get():
                characters += string.digits
            if self.include_special.get():
                characters += string.punctuation

            # Ensure there's at least one character type selected
            if not characters:
                raise ValueError("Select at least one character type.")

            # Generate the password
            password = ''.join(random.choice(characters) for _ in range(length))
            self.result_label.config(text=f"Generated Password: {password}")
        except ValueError as e:
            messagebox.showerror("Input Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = AdvancedPasswordGenerator(root)
    root.mainloop()
