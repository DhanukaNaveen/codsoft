#include <iostream>
#include <limits>

using namespace std;

double add(double x, double y) { return x + y; }
double subtract(double x, double y) { return x - y; }
double multiply(double x, double y) { return x * y; }
double divide(double x, double y) {
    if (y == 0) {
        cout << "Error: Cannot divide by zero!" << endl;
        return numeric_limits<double>::quiet_NaN(); // Return NaN for division by zero
    }
    return x / y;
}

int main() {
    cout << "Welcome to Simple Calculator!" << endl;
    char continueCalc;

    do {
        double firstNum, secondNum;
        char op;

        cout << "\nPlease enter the first number: ";
        cin >> firstNum;
        cout << "Enter an operation (+, -, *, /): ";
        cin >> op;
        cout << "Please enter the second number: ";
        cin >> secondNum;

        double outcome;

        switch (op) {
            case '+': outcome = add(firstNum, secondNum); break;
            case '-': outcome = subtract(firstNum, secondNum); break;
            case '*': outcome = multiply(firstNum, secondNum); break;
            case '/': outcome = divide(firstNum, secondNum); break;
            default:
                cout << "Error: Invalid operation!" << endl;
                continue;
        }

        cout << "Calculation: " << firstNum << " " << op << " " << secondNum << " = " << outcome << endl;
        cout << "\nWould you like to calculate again? (Y/N): ";
        cin >> continueCalc;

    } while (continueCalc == 'Y' || continueCalc == 'y');

    return 0;
}
