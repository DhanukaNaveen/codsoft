import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CurrencyConverter {
    private static final String API_ENDPOINT = "https://api.exchangerate-api.com/v4/latest/";

    public static void main(String[] args) {
        JFrame frame = new JFrame("Currency Converter");
        JPanel panel = new JPanel();
        JTextField inputAmount = new JTextField(10);
        JTextArea outputArea = new JTextArea(5, 20);
        JButton convertButton = new JButton("Convert");

        String[] currencyOptions = {"USD", "EUR", "JPY", "LKR"};
        JComboBox<String> baseCurrencySelector = new JComboBox<>(currencyOptions);
        JComboBox<String> targetCurrencySelector = new JComboBox<>(currencyOptions);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        panel.add(new JLabel("Amount:"));
        panel.add(inputAmount);
        panel.add(new JLabel("From:"));
        panel.add(baseCurrencySelector);
        panel.add(new JLabel("To:"));
        panel.add(targetCurrencySelector);
        panel.add(convertButton);
        panel.add(outputArea);
        frame.add(panel);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fromCurrency = (String) baseCurrencySelector.getSelectedItem();
                String toCurrency = (String) targetCurrencySelector.getSelectedItem();

                if (fromCurrency != null && toCurrency != null) {
                    try {
                        double amount = Double.parseDouble(inputAmount.getText());
                        double result = performConversion(amount, fromCurrency, toCurrency);
                        outputArea.setText("Converted Amount: " + result + " " + toCurrency);
                    } catch (NumberFormatException ex) {
                        outputArea.setText("Please enter a valid amount.");
                    }
                }
            }
        });
    }

    private static double performConversion(double amount, String fromCurrency, String toCurrency) {
        Map<String, Double> rates = getExchangeRates(fromCurrency);
        return amount * rates.get(toCurrency);
    }

    private static Map<String, Double> getExchangeRates(String baseCurrency) {
        Map<String, Double> exchangeRates = new HashMap<>();
        try {
            URL url = new URL(API_ENDPOINT + baseCurrency);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();

            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                throw new RuntimeException("Failed to connect: HTTP error code " + responseCode);
            }

            Scanner scanner = new Scanner(url.openStream());
            StringBuilder response = new StringBuilder();
            while (scanner.hasNext()) {
                response.append(scanner.nextLine());
            }
            scanner.close();

            String jsonResponse = response.toString();
            String[] currencyList = {"USD", "EUR", "JPY", "LKR"};
            for (String currency : currencyList) {
                String rateString = jsonResponse.split(currency + "\":")[1].split(",")[0];
                exchangeRates.put(currency, Double.parseDouble(rateString));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exchangeRates;
    }
}
