import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class GuessingGame {
    private int targetNumber;
    private int maxAttempts = 8;
    private int currentAttempts;

    public GuessingGame() {
        JFrame frame = new JFrame("Guess the Number Game");
        JPanel panel = new JPanel();
        JTextField guessField = new JTextField(10);
        JTextArea feedbackArea = new JTextArea(5, 20);
        JButton guessButton = new JButton("Guess");
        JButton newGameButton = new JButton("New Game");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);
        panel.add(new JLabel("Guess a number (1-100):"));
        panel.add(guessField);
        panel.add(guessButton);
        panel.add(newGameButton);
        panel.add(feedbackArea);
        frame.add(panel);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

        startNewGame();

        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentAttempts < maxAttempts) {
                    currentAttempts++;
                    int userGuess = Integer.parseInt(guessField.getText());
                    if (userGuess < targetNumber) {
                        feedbackArea.setText("Too low! Attempts left: " + (maxAttempts - currentAttempts));
                    } else if (userGuess > targetNumber) {
                        feedbackArea.setText("Too high! Attempts left: " + (maxAttempts - currentAttempts));
                    } else {
                        feedbackArea.setText("Correct! You've guessed the number!");
                        startNewGame();
                    }
                } else {
                    feedbackArea.setText("Out of attempts! The number was: " + targetNumber);
                    startNewGame();
                }
            }
        });

        newGameButton.addActionListener(e -> {
            startNewGame();
            feedbackArea.setText("New game started! You have " + maxAttempts + " attempts.");
        });
    }

    private void startNewGame() {
        Random random = new Random();
        targetNumber = random.nextInt(100) + 1;
        currentAttempts = 0;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GuessingGame::new);
    }
}
