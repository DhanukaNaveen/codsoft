import tkinter as tk
from tkinter import messagebox

class SimpleCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple Calculator")
        self.root.geometry("300x400")
        
        self.result_var = tk.StringVar()

        # Entry field for calculation
        entry = tk.Entry(self.root, textvariable=self.result_var, font=("Helvetica", 16), bd=5, insertwidth=2, width=14)
        entry.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

        # Calculator buttons
        buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('C', 4, 1), ('=', 4, 2), ('+', 4, 3),
        ]

        for (text, r, c) in buttons:
            if text == '=':
                btn = tk.Button(self.root, text=text, command=self.calculate, bg="#4CAF50", fg="white")
            elif text == 'C':
                btn = tk.Button(self.root, text=text, command=self.clear, bg="#F44336", fg="white")
            else:
                btn = tk.Button(self.root, text=text, command=lambda t=text: self.append_to_expression(t))
            btn.grid(row=r, column=c, padx=5, pady=5)

    def append_to_expression(self, value):
        current_text = self.result_var.get()
        self.result_var.set(current_text + value)

    def clear(self):
        self.result_var.set("")

    def calculate(self):
        try:
            result = eval(self.result_var.get())
            self.result_var.set(result)
        except Exception as e:
            messagebox.showerror("Error", "Invalid input!")
            self.clear()

if __name__ == "__main__":
    root = tk.Tk()
    app = SimpleCalculator(root)
    root.mainloop()
