import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GradeCalculatorApp {
    public static void main(String[] args) {
        JFrame window = new JFrame("Grade Evaluation");
        JPanel panel = new JPanel();
        JTextField marksField = new JTextField(20);
        JTextArea resultArea = new JTextArea(5, 20);
        JButton calculateButton = new JButton("Calculate");

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500, 300);
        panel.add(new JLabel("Enter marks (comma-separated):"));
        panel.add(marksField);
        panel.add(calculateButton);
        panel.add(resultArea);
        window.add(panel);
        window.setVisible(true);
        window.setLocationRelativeTo(null);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] marksArray = marksField.getText().split(",");
                int total = 0;
                for (String mark : marksArray) {
                    total += Integer.parseInt(mark.trim());
                }

                double average = total / (double) marksArray.length;
                char grade;
                if (average >= 75) {
                    grade = 'A';
                } else if (average >= 65) {
                    grade = 'B';
                } else if (average >= 55) {
                    grade = 'C';
                } else if (average >= 45) {
                    grade = 'D';
                } else {
                    grade = 'F';
                }

                resultArea.setText("Total: " + total + "\nAverage: " + average + "\nGrade: " + grade);
            }
        });
    }
}
