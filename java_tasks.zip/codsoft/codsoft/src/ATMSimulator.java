import javax.swing.*;

class UserAccount {
    private double accountBalance;

    public UserAccount(double initialBalance) {
        accountBalance = initialBalance;
    }

    public double getBalance() {
        return accountBalance;
    }

    public void depositFunds(double amount) {
        accountBalance += amount;
    }

    public boolean withdrawFunds(double amount) {
        if (amount <= accountBalance) {
            accountBalance -= amount;
            return true;
        }
        return false;
    }
}

public class ATMSimulator {
    public static void main(String[] args) {
        UserAccount account = new UserAccount(500); // Initial balance
        JFrame frame = new JFrame("ATM Simulator");
        JPanel panel = new JPanel();
        JTextArea displayArea = new JTextArea(5, 20);
        JTextField amountField = new JTextField(10);
        JButton checkBalanceButton = new JButton("Check Balance");
        JButton depositButton = new JButton("Deposit");
        JButton withdrawButton = new JButton("Withdraw");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        panel.add(checkBalanceButton);
        panel.add(new JLabel("Amount:"));
        panel.add(amountField);
        panel.add(depositButton);
        panel.add(withdrawButton);
        panel.add(displayArea);
        frame.add(panel);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

        checkBalanceButton.addActionListener(e -> displayArea.setText("Balance: " + account.getBalance()));

        depositButton.addActionListener(e -> {
            double amount = Double.parseDouble(amountField.getText());
            account.depositFunds(amount);
            displayArea.setText("Deposited: " + amount);
        });

        withdrawButton.addActionListener(e -> {
            double amount = Double.parseDouble(amountField.getText());
            if (account.withdrawFunds(amount)) {
                displayArea.setText("Withdrawn: " + amount);
            } else {
                displayArea.setText("Insufficient funds.");
            }
        });
    }
}
