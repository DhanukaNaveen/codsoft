import tkinter as tk
from tkinter import messagebox, font

class ToDoListApp:
    def __init__(self, root):
        self.root = root
        self.root.title("My To-Do List")
        self.root.geometry("400x400")
        self.root.config(bg="#f9f9f9")

        self.tasks = []

        # Title label
        title_label = tk.Label(self.root, text="To-Do List", font=("Helvetica", 16), bg="#f9f9f9")
        title_label.pack(pady=10)

        # Entry box for new tasks
        self.task_entry = tk.Entry(self.root, width=30, font=("Helvetica", 12))
        self.task_entry.pack(pady=10)

        # Add Task button
        add_task_btn = tk.Button(self.root, text="Add Task", command=self.add_task, bg="#4CAF50", fg="white")
        add_task_btn.pack(pady=5)

        # Listbox to display tasks
        self.task_listbox = tk.Listbox(self.root, width=50, height=10)
        self.task_listbox.pack(pady=10)

        # Buttons for completing and deleting tasks
        complete_btn = tk.Button(self.root, text="Complete Task", command=self.complete_task, bg="#2196F3", fg="white")
        complete_btn.pack(side=tk.LEFT, padx=(20, 5), pady=5)

        delete_btn = tk.Button(self.root, text="Delete Task", command=self.delete_task, bg="#F44336", fg="white")
        delete_btn.pack(side=tk.RIGHT, padx=(5, 20), pady=5)

    def add_task(self):
        task = self.task_entry.get()
        if task:
            self.tasks.append(task)
            self.task_listbox.insert(tk.END, task)
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Warning", "You must enter a task.")

    def complete_task(self):
        try:
            selected_index = self.task_listbox.curselection()[0]
            self.task_listbox.itemconfig(selected_index, {'bg': '#d9ffd9'})  # Highlight completed task
            self.tasks[selected_index] += " (Completed)"
            self.task_listbox.delete(selected_index)
            self.task_listbox.insert(selected_index, self.tasks[selected_index])
        except IndexError:
            messagebox.showwarning("Warning", "Select a task to complete.")

    def delete_task(self):
        try:
            selected_index = self.task_listbox.curselection()[0]
            self.tasks.pop(selected_index)
            self.task_listbox.delete(selected_index)
        except IndexError:
            messagebox.showwarning("Warning", "Select a task to delete.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoListApp(root)
    root.mainloop()
