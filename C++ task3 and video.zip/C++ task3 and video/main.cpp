#include <iostream>
#include <vector>
using namespace std;

void displayBoard(const vector<char>& board) {
    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            cout << board[row * 3 + col] << " ";
        }
        cout << endl;
    }
}

bool checkWin(const vector<char>& board, char player) {
    for (int i = 0; i < 3; ++i) {
        if ((board[i * 3] == player && board[i * 3 + 1] == player && board[i * 3 + 2] == player) ||
            (board[i] == player && board[i + 3] == player && board[i + 6] == player)) {
            return true;
        }
    }
    return (board[0] == player && board[4] == player && board[8] == player) ||
           (board[2] == player && board[4] == player && board[6] == player);
}

bool checkDraw(const vector<char>& board) {
    for (char cell : board) {
        if (cell == ' ') return false;
    }
    return true;
}

int main() {
    cout << "Welcome to Tic-Tac-Toe!" << endl;
    char replay;

    do {
        vector<char> board(9, ' '); // 3x3 board initialized with spaces
        char currentPlayer = 'X';
        int position;

        while (true) {
            displayBoard(board);
            cout << "Player " << currentPlayer << ", select a position (1-9): ";
            cin >> position;

            if (position < 1 || position > 9 || board[position - 1] != ' ') {
                cout << "Invalid move. Please choose another position." << endl;
                continue;
            }

            board[position - 1] = currentPlayer;

            if (checkWin(board, currentPlayer)) {
                displayBoard(board);
                cout << "Congratulations! Player " << currentPlayer << " wins!" << endl;
                break;
            }

            if (checkDraw(board)) {
                displayBoard(board);
                cout << "It's a draw!" << endl;
                break;
            }

            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        cout << "Would you like to play again? (Y/N): ";
        cin >> replay;

    } while (replay == 'Y' || replay == 'y');

    return 0;
}
